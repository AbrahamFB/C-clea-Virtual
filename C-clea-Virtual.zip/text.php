<!DOCTYPE html>
<html lang="es">

<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

</head>

<body>
        <style>
                h1,
                p {
                        font-family: Arial, Helvetica, sans-serif;
                }
        </style>
        <h1 style="text-align: center; text-transform: uppercase; ">Bienvenido <?php echo $user ?> </h1>
        <br>


        <p style="text-align: center;">Comienza a disfrutar de los beneficios de Cóclea Virtual</p>

        <p style="text-align:center;"><a href="https://cv.gala-dev/perfil.php" style="text-decoration: none;">Ve nuestra
                        página</a></p>
        </a>
</body>

</html>