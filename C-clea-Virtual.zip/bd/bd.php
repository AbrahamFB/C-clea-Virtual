<?php
$conexion = mysqli_connect("162.241.62.191", "tecnoso5_master", "nKwuIMe#Nj*8", "tecnoso5_cocleavirtual");
?>