#!/bin/bash
php index.php
