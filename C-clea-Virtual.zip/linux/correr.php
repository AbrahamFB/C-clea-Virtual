<?php exec("/home/aa/scripts/test.sh");
?>