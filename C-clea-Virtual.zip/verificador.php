<?php
$anadirURL = "";
$nombrePagina = "Cóclea Virtual - Verificador";
$css_extra = "";
$user = "Alfredo";

include("html.php");

echo '<body ondragstart="return false">';

include("nav-bar_index.php");


?>

            <iframe width="100%" height="1000000000000000000" src="../startbootstrap-sb-admin-2-gh-pages/index.html"></iframe>


<?php

include("footer.php");

include("scripts.php");

echo '  </body>
</html>';
