<?php 
    header("location:perfil.php");
?>