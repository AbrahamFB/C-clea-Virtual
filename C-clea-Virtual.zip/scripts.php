<?php

echo '<!-- JavaScript Librerias -->';
echo '<script src="' . $anadirURL . 'lib/jquery/jquery.min.js"></script>';
echo '<script src="' . $anadirURL . 'lib/jquery/jquery-migrate.min.js"></script>';
echo '<script src="' . $anadirURL . 'lib/bootstrap/js/bootstrap.bundle.min.js"></script>';
echo '<script src="' . $anadirURL . 'lib/typed/typed.js"></script>';
echo '<script src="' . $anadirURL . 'lib/owlcarousel/owl.carousel.min.js"></script>';
echo '<script src="' . $anadirURL . 'lib/magnific-popup/magnific-popup.min.js"></script>';
echo '<script src="' . $anadirURL . 'lib/isotope/isotope.pkgd.min.js"></script>';
echo '<script src="' . $anadirURL . 'js/validacion-registro.js"></script>';

echo '<!-- Template Main Javascript Archivo -->';
echo '<script src="' . $anadirURL . 'js/main.js"></script>';
echo '<script src="' . $anadirURL . 'js/modernizr.js"></script>';

echo '<!-- Bootstrap -->';
echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>';

echo '<!-- Iconos -->';
echo '<script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>';

?>

